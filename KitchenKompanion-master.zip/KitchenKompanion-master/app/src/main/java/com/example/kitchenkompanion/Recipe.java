package com.example.kitchenkompanion;

import java.io.Serializable;
import java.util.HashSet;

public class Recipe implements Serializable, Comparable {

    public final static String[] DIETARY_RESTRICTIONS = {"Vegan", "Keto", "Non-Dairy"};
    public final static double NEGLIGIBLE_QUANTITY = 0.000001;

    private final String name;
    private final String difficulty;
    private final int servings;
    private final InventoryItem[] ingredients;
    private final String[] steps;
    private boolean favorite;
    private final int imagePath;
    private final int minutes;
    private final String[] dietaryRestrictions;

    private HashSet<String> searchStrings;

    public Recipe(String name, String difficulty, int servings, InventoryItem[] ingredients, String[] steps, boolean favorite, int imagePath, int minutes, String[] dietaryRestrictions) {
        this.name = name;
        this.difficulty = difficulty;
        this.servings = servings;
        this.ingredients = ingredients;
        this.steps = steps;
        this.favorite = favorite;
        this.imagePath = imagePath;
        this.minutes = minutes;
        this.dietaryRestrictions = dietaryRestrictions;

        // add filter results
        searchStrings = new HashSet<>();
        for (String n : name.split(" "))
            searchStrings.add(n.toLowerCase());
        if (dietaryRestrictions != null)
            for (String d : dietaryRestrictions)
                searchStrings.add(d.toLowerCase());
        searchStrings.add(difficulty.toLowerCase());
        searchStrings.add(name.toLowerCase());
    }

    public String getName() {
        return name;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public int getServings() {
        return servings;
    }

    public InventoryItem[] getIngredients() {
        return ingredients;
    }

    public String[] getSteps() {
        return steps;
    }

    public boolean getFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) { this.favorite = favorite; }

    public int getImagePath() {
        return imagePath;
    }

    public int getMinutes() {
        return minutes;
    }

    public String[] getDietaryRestrictions() {
        return dietaryRestrictions;
    }

    public HashSet<String> getSearchStrings() {
        return searchStrings;
    }

    @Override
    public String toString() {
        return "Recipe: " + name;
    }

    @Override
    public int compareTo(Object o) {
        return 0; // TODO @JAMES
    }
}
