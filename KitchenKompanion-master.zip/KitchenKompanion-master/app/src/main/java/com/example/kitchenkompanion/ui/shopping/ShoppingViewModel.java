package com.example.kitchenkompanion.ui.shopping;

import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.navigation.Navigation;

import com.example.kitchenkompanion.InventoryItem;
import com.example.kitchenkompanion.R;
import com.example.kitchenkompanion.ShoppingList;


import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ShoppingViewModel extends ViewModel {

    public static MutableLiveData<TableLayout> mTableLayout;
    public static MutableLiveData<List<ShoppingList>> shoppingLists;
    private static androidx.fragment.app.FragmentActivity activity;
    private static View view;
    public static ShoppingList currentShoppingList;
    private final static int DEFAULT_PADDING = 8;

    // Get Around to provide activity to provide activity to the
    // Shopping View Model
    public void setActivity(androidx.fragment.app.FragmentActivity a){
        if (activity == null) {
            activity = a;
        }

    }

    // Important: this is a sketchy get-around to provide activity to view model
    // so that we can create dynamic xml elements.
    // ONLY ASSIGN ONCE
    public void setView(View v) {
        if (this.view == null) {
            this.view = v;
        }
    }

    // Constructor: Load table data to the view
    public ShoppingViewModel() {
        if (mTableLayout == null) {
            mTableLayout = new MutableLiveData<>();
        }
//        System.out.println("Initialize Table Layout");
//        System.out.println(mTableLayout.getValue());
        // ToDo: Call function to load default shopping lists
        loadDefaultShoppingLists();
    }

    // Initialize Table Layout
    public void initTableLayout(){
        TableLayout tableLayout = new TableLayout(activity);
        tableLayout.setStretchAllColumns(true);
        mTableLayout.setValue(tableLayout);
        createTable(shoppingLists.getValue());
    }


    // Adds Header Row and subsequential rows to the table
    private void createTable(List<ShoppingList> shoppingLists){
        mTableLayout.getValue().removeAllViews();
        createHeaderRow();
        // Add lists to table
        for (ShoppingList list: shoppingLists){
            addTableRow(list);
        }
    }

    // Creates Header Row fpr the table
    private void createHeaderRow(){
        /* Create a new header row to be added */
        TableRow hdr = new TableRow(activity);
        /* set background color, layout params, padding, and generate Id for hdr row */
        //hdr.setBackgroundColor(activity.getResources().getColor(R.color.background_grey));
        hdr.setBackground(activity.getResources().getDrawable(R.drawable.list_item_white));
        hdr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        hdr.setId(hdr.generateViewId());
        hdr.setPadding(DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING);
        addRowElements(hdr, "Name", "Date Modified", true);
        mTableLayout.getValue().addView(hdr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

    }

    // Create a row for a shopping list
    private void addTableRow(ShoppingList list){
        /* Create a New Row to be Added */
        System.out.println("addTableRow");
        System.out.println(activity);
        TableRow tr = new TableRow(activity);

        tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        tr.setBackground(activity.getResources().getDrawable(R.drawable.list_item_white));
        tr.setPadding(DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING);
        addRowElements(tr, list.getName(), String.valueOf(list.getDateModified()), false);


        mTableLayout.getValue().addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));
        // ToDo: Add on click listener that will take user to new actvity displaying actual content of list
        tr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentShoppingList = list;
                Navigation.findNavController(v).navigate(R.id.individualListFragment);
            }
        });
    }

    // Create a textview with proper settings
    private void setTextViewSettings(TextView textView, String text, int maxWidth, boolean bold) {
        textView.setMaxWidth(maxWidth);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setMaxLines(1);
        textView.setTextSize(18);
        textView.setText(text);
        textView.setPadding(DEFAULT_PADDING, 0, DEFAULT_PADDING, 0);
        if (bold) textView.setTypeface(null, Typeface.BOLD);
    }


    private void addRowElements(TableRow tr, String name, String dateModified, boolean bold){
        /* Create a textview to be the row-content (shopping list name) */
        TextView tvName = new TextView(activity);
        setTextViewSettings(tvName, name, 128, bold);
        tr.addView(tvName);

        /* Create a textview to be the row-content (dateModified) */
        TextView tvDateModified = new TextView(activity);
        setTextViewSettings(tvDateModified, dateModified, 128, bold);
        tr.addView(tvDateModified);
    }

    public void loadDefaultShoppingLists(){
        shoppingLists = new MutableLiveData<List<ShoppingList>>();

        InventoryItem[][] items = {
                {
                        new InventoryItem("Milk", 1, "gal"),
                        new InventoryItem("Eggs", 12, "#"),
                        new InventoryItem("Ice Cream", 1, "gal"),
                },
                {
                        new InventoryItem("Flour", 12, "cups"),
                        new InventoryItem("Eggs", 12, "#"),
                        new InventoryItem("Chocolate chips", 8, "cups"),
                },
                {
                        new InventoryItem("Cake", 1, "#"),
                        new InventoryItem("Pizza", 10, "#"),
                        new InventoryItem("Coke", 4, "gal"),
                }

        };

        ShoppingList[] defaultShoppingLists = {
                new ShoppingList("Weekly List", LocalDate.of(2022, Month.APRIL, 2), new ArrayList<>(Arrays.asList(items[0]))),
                new ShoppingList("Baking", LocalDate.of(2022, Month.APRIL, 2), new ArrayList<>(Arrays.asList(items[1]))),
                new ShoppingList("Birthday Party", LocalDate.of(2022, Month.APRIL, 2), new ArrayList<>(Arrays.asList(items[2]))),
        };

        shoppingLists.setValue(new ArrayList<>(Arrays.asList(defaultShoppingLists)));
    }

    public void addShoppingList(ShoppingList list){
        if (shoppingLists == null){
            loadDefaultShoppingLists();
        }
        shoppingLists.getValue().add(list);
        addTableRow(list);
    }

    public void removeShoppingList(ShoppingList list){
        if (shoppingLists != null){
            shoppingLists.getValue().remove(list);
            createTable(shoppingLists.getValue());
        }
    }

    public LiveData<TableLayout> getTableLayout() { return mTableLayout; }

}