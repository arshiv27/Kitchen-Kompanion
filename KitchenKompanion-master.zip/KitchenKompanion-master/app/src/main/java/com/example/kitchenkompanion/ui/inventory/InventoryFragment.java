package com.example.kitchenkompanion.ui.inventory;
import androidx.fragment.app.DialogFragment;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

import com.example.kitchenkompanion.InventoryItem;
import com.example.kitchenkompanion.R;
import com.example.kitchenkompanion.Recipe;
import com.example.kitchenkompanion.databinding.FragmentInventoryBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class InventoryFragment extends Fragment {

    public static String TAG = "InventoryFragment";
    private FragmentInventoryBinding binding;
    private InventoryViewModel inventoryViewModel;

    private SearchView searchView;
    private HashSet currSearchStringSet;
    private ArrayAdapter<String> arrayAdapter;
    private ListView listView;

    FloatingActionButton fab;

    // this is a comment
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        System.out.println("Hit Inventory");
        // Get inventory view model
        inventoryViewModel =
                new ViewModelProvider(getActivity()).get(InventoryViewModel.class);
        // init activity (sketchy)
        inventoryViewModel.setActivity(getActivity());

        binding = FragmentInventoryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        inventoryViewModel.setView(root);

        // init the table (header and default data)
        inventoryViewModel.initTableLayout();

        // bind the table to the xml
        final TableLayout tableLayout = binding.inventoryTableLayout;
        inventoryViewModel.getTableLayout().observe(getViewLifecycleOwner(), tableLayout::addView);

        listView = root.findViewById(R.id.inventory_listview);
        listView.setVisibility(View.GONE);
        arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, createSearchStrings());
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(messageClickedHandler);

        // floating button
        fab = root.findViewById(R.id.floatingAddButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CreateItemDialogFragment createItemDialogFragment = new CreateItemDialogFragment();
                createItemDialogFragment.show(getChildFragmentManager(), CreateItemDialogFragment.TAG);
            }
        });

        // expired alert button
        root.findViewById(R.id.inventory_expired_alert_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((LinearLayout) root.findViewById(R.id.inventory_expired_alert_layout)).setVisibility(View.GONE);
                inventoryViewModel.setExpiredAlertOff();
            }
        });

        // expired alert button
        root.findViewById(R.id.inventory_near_expired_alert_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((LinearLayout) root.findViewById(R.id.inventory_near_expired_alert_layout)).setVisibility(View.GONE);
                inventoryViewModel.setNearExpiredAlertOff();
            }
        });

        return root;
    }

    // Create a message handling object as an anonymous class.
    private AdapterView.OnItemClickListener messageClickedHandler;
    {
        messageClickedHandler = new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // when click on row, populate search bar with term
                searchView.setQuery(((TextView) v).getText(), true);
            }
        };
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true); // It's important here
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();

        inflater.inflate(R.menu.inventory_menu, menu);
        MenuItem item = menu.findItem(R.id.action_search_inventory);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

        listView.setVisibility(View.GONE);
        searchView = (SearchView) item.getActionView();
        searchView.setQueryHint("Search for item");
        searchView.setMaxWidth(Integer.MAX_VALUE); // make it take the full header when open

        // set search query to saved search string
        searchView.post(new Runnable() {
            @Override
            public void run() {
                // Important! Make sure searchView has been initialized
                // and referenced to the correct (current) SearchView.
                // Config changes (e.g. screen rotation) may make the
                // variable value null.
                searchView.setQuery("", false);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                listView.setVisibility(View.GONE);
                inventoryViewModel.setCurrFilters(createBase(query));
                searchView.clearFocus();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.length() == 0) {
                    listView.setVisibility(View.GONE);
                    inventoryViewModel.setCurrFilters(null);
                } else {
                    listView.setVisibility(View.VISIBLE);
                    if (newText.charAt(newText.length()-1) == ' ') {
                        // make sure word is already in our search strings
                        if (currSearchStringSet.contains(newText.trim())) {
                            arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, createSearchStrings(createBase(newText.trim())));
                            listView.setAdapter(arrayAdapter);
                        }
                    }
                }
                arrayAdapter.getFilter().filter(newText);
                return true;
            }
        });

        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                inventoryViewModel.setCurrFilters(null);
                return false;
            }
        });
    }

    // create filter
    private HashSet<String> createBase(String text) {
        HashSet<String> base = new HashSet<>();
        for (String n : text.split(" "))
            base.add(n.toLowerCase());
        return base;
    }

    // create search strings (combo of names, location, and owner)
    // assume createSearchStrings() was already called and inited search strings
    private List<String> createSearchStrings(HashSet<String> base) {
        String baseString = "";
        for (String b : base)
            baseString += b + " ";

        currSearchStringSet = new HashSet<>();
        for (InventoryItem item : inventoryViewModel.getInventoryItems()) {
            if (item.getSearchStrings().containsAll(base)) {
                for (String searchString : item.getSearchStrings()) {
                    if (!base.contains(searchString))
                        currSearchStringSet.add(baseString + searchString);
                }
            }
        }
        ArrayList<String> l = new ArrayList<>();
        l.addAll(currSearchStringSet);
        return l;
    }

    // create search strings (names, diets, and difficulty)
    private List<String> createSearchStrings() {
        // so we don't get duplicates
        currSearchStringSet = new HashSet<>();
        for (InventoryItem item : inventoryViewModel.getInventoryItems())
            currSearchStringSet.addAll(item.getSearchStrings());

        ArrayList<String> l = new ArrayList<>();
        l.addAll(currSearchStringSet);
        return l;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}