package com.example.kitchenkompanion.ui.recipe;

import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.kitchenkompanion.InventoryItem;
import com.example.kitchenkompanion.R;
import com.example.kitchenkompanion.Recipe;
import com.example.kitchenkompanion.ui.inventory.InventoryViewModel;

import java.util.ArrayList;
import java.util.List;

public class RecipeDialogFragment extends DialogFragment {

    public static String TAG = "RecipeDialog";
    private Recipe recipe;
    private InventoryViewModel inventoryViewModel;
    private ArrayList<InventoryItem> missingIngredients;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Bundle bundle = getArguments();
        recipe = (Recipe) bundle.getSerializable("recipe");
        inventoryViewModel = new ViewModelProvider(getActivity()).get(InventoryViewModel.class);

        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        // update xml view
        View view = getActivity().getLayoutInflater().inflate(R.layout.recipe_dialog_fragment, null);
        updateView(view);

        // compute missing ingredients
        missingIngredients = new ArrayList<>();
        collectMissingIngredients(missingIngredients);
        String positiveButtonName = missingIngredients.isEmpty() ? "Deduct from Inventory" : "Add Missing to List";

        builder.setTitle(recipe.getName())
                .setView(view)
                .setPositiveButton(positiveButtonName, new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    { /* do nothing here, override below */ }
                })
                .setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Send the negative button event back to the host activity
                        listener.onDialogNeutralClick(RecipeDialogFragment.this);
                    }
                });

        // overwrite the positive button functionality
        final AlertDialog dialog = builder.create();
        dialog.show();

        // create confirmation message for removing items from inventory
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // confirmation popup
                if (missingIngredients.isEmpty()) {
                    new AlertDialog.Builder(getActivity())
                            .setTitle("Are you sure?")
                            .setMessage("This action will remove multiple items from the inventory.")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface innerDialog, int whichButton) {
                                    listener.onDialogPositiveClick(RecipeDialogFragment.this);
                                    dialog.dismiss();
                                }})
                            .setNeutralButton("Cancel", null).show();
                } else {
                    listener.onDialogPositiveClick(RecipeDialogFragment.this);
                }
            }
        });

        // Create the AlertDialog object and return it
        return dialog;
    }

    private void collectMissingIngredients(List<InventoryItem> missingIngredients) {
        for (InventoryItem ingredient : recipe.getIngredients()) {
            double currentQuantity = inventoryViewModel.getMyItemQuantity(ingredient.getName());
            // check if need to buy more of ingredient
            if (!ingredient.getName().equalsIgnoreCase("water") && currentQuantity < ingredient.getQuantity()) {
                double neededQuantity = ingredient.getQuantity() - currentQuantity;
                // check if need negligible quantity (like for spices)
                if (neededQuantity == Recipe.NEGLIGIBLE_QUANTITY)
                    neededQuantity = 1;
                missingIngredients.add(new InventoryItem(ingredient.getName(), neededQuantity, ingredient.getUnit()));
            }
        }
    }

    private void updateView(View view) {
        // Update image
        ((ImageView) view.findViewById(R.id.recipe_image)).setImageResource(recipe.getImagePath());

        // update servings
        String servingsText = "(for " + String.valueOf(recipe.getServings()) + " serving";
        if (recipe.getServings() > 1)
            servingsText += "s";
        servingsText += ")";
        ((TextView) view.findViewById(R.id.recipe_servings)).setText(servingsText);

        // update ingredients
        LinearLayout recipeIngredientsList = (LinearLayout) view.findViewById(R.id.recipe_ingredients_list);
        for (InventoryItem item : recipe.getIngredients()) {
            recipeIngredientsList.addView(updateIngredientView(item));
        }

        // update diet
        if (recipe.getDietaryRestrictions() == null) {
            ((LinearLayout) view.findViewById(R.id.recipe_v_linear_layout)).removeView(view.findViewById(R.id.recipe_diet_header));
            ((LinearLayout) view.findViewById(R.id.recipe_v_linear_layout)).removeView(view.findViewById(R.id.recipe_diet));
        } else {
            String dietText = "";
            for (String diet : recipe.getDietaryRestrictions())
                dietText += diet + " ";
            ((TextView) view.findViewById(R.id.recipe_diet)).setText(dietText);
        }

        // update prep time & beginner friendly
        int prepTime = recipe.getMinutes();
        int hours = prepTime / 60;
        int minutes = prepTime % 60;
        String prepTimeText = "(";
        if (hours > 0)
            prepTimeText += hours + " hr";
        if (hours > 0 && minutes > 0)
            prepTimeText += " ";
        if (minutes > 0)
            prepTimeText += minutes + " min";

        prepTimeText += " - " + recipe.getDifficulty().toLowerCase();
        prepTimeText += ")";

        ((TextView) view.findViewById(R.id.recipe_prep_time)).setText(prepTimeText);

        // update steps
        for (int i = 0; i < recipe.getSteps().length; i++) {
            ((LinearLayout) view.findViewById(R.id.recipe_steps_list)).addView(updateStepView(i + 1, recipe.getSteps()[i]));
        }

    }

    private View updateIngredientView(InventoryItem item) {
        // create linear layout
        LinearLayout ll = new LinearLayout(getActivity());
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setPadding(0, 4, 0, 4);
        ll.setWeightSum(2);
        ll.setBackground(getActivity().getResources().getDrawable(R.drawable.list_item_white));
        ll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // create ingredient
        TextView ingredient = new TextView(getActivity());
        String ingredientText = item.getName().toLowerCase();
        ingredient.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
        ));
        // set text color if not enough
        double currentQuantity = inventoryViewModel.getMyItemQuantity(item.getName());
        if (!item.getName().equalsIgnoreCase("water") && currentQuantity < item.getQuantity()) {
            ingredient.setTextColor(getActivity().getResources().getColor(R.color.red));
            ingredientText += " (" + String.valueOf((int) currentQuantity) + "/" + String.valueOf((int) item.getQuantity()) + ")";
        }
        ingredient.setText(ingredientText);

        // create quantity
        TextView quantity = new TextView(getActivity());
        String quantityText = "";
        // Check if needed (> Recipe.NEGLIGIBLE_QUANTITY)
        if (item.getQuantity() > Recipe.NEGLIGIBLE_QUANTITY)
            quantityText = String.valueOf((int) item.getQuantity());
        // Check if units needed (not amount)
        if (!item.getUnit().equals("#"))
            quantityText += " " + item.getUnit();
        quantity.setText(quantityText);
        quantity.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
        ));
        quantity.setGravity(Gravity.RIGHT);

        ll.addView(ingredient);
        ll.addView(quantity);

        return ll;
    }

    private View updateStepView(int i, String stepText) {
        // create linear layout
        LinearLayout ll = new LinearLayout(getActivity());
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setPadding(0, 4, 0, 4);
        ll.setWeightSum(10);
        ll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // create number
        TextView number = new TextView(getActivity());
        number.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                9.0f
        ));
        number.setTypeface(null, Typeface.BOLD);
        number.setText(String.valueOf(i));

        // create step
        TextView step = new TextView(getActivity());
        step.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1.0f
        ));
        step.setText(String.valueOf(stepText));

        ll.addView(number);
        ll.addView(step);
        return ll;
    }


    /* The activity that creates an instance of this dialog fragment must
     * implement this interface in order to receive event callbacks.
     * Each method passes the DialogFragment in case the host needs to query it. */
    public interface RecipeDialogListener {
        public void onDialogPositiveClick(DialogFragment dialog);
        public void onDialogNegativeClick(DialogFragment dialog);
        public void onDialogNeutralClick(DialogFragment dialog);
    }

    // Use this instance of the interface to deliver action events
    RecipeDialogFragment.RecipeDialogListener listener;

    // Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            listener = (RecipeDialogFragment.RecipeDialogListener) context;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException("must implement RecipeDialogListener");
        }
    }

    public Recipe getRecipe() {
        return recipe;
    }

    public ArrayList<InventoryItem> getMissingIngredients() {
        return missingIngredients;
    }

}