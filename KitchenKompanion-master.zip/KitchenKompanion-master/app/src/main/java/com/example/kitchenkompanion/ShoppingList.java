package com.example.kitchenkompanion;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;

public class ShoppingList implements Serializable {
    private String shoppingListName;
    private LocalDate dateModified;
    private List<InventoryItem> items;
    private HashSet<InventoryItem> selected;

    public ShoppingList(String shoppingListName, LocalDate dateModified, List<InventoryItem> items){
        this.shoppingListName = shoppingListName;
        this.dateModified = dateModified;
        this.items = items;
        this.selected = new HashSet<>();
    }

    public void setName(String shoppingListName){
        this.shoppingListName = shoppingListName;
    }

    public String getName(){
        return shoppingListName;
    }

    public void setDateModified(LocalDate dateModified){
        this.dateModified = dateModified;
    }

    public LocalDate getDateModified(){
        return dateModified;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof ShoppingList))
            return false;
        ShoppingList other = (ShoppingList) o;
        return this.shoppingListName.equalsIgnoreCase(other.getName());
    }

    @Override
    public final int hashCode() {
        return (this.shoppingListName.toLowerCase()).hashCode();
    }


    public List<InventoryItem> getItems() {
        return items;
    }

    public void setItems(List<InventoryItem> items) {
        this.items = items;
    }

    public HashSet<InventoryItem> getSelected() {
        return selected;
    }
}
