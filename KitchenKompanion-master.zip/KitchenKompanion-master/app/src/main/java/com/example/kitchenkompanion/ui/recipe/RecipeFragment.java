package com.example.kitchenkompanion.ui.recipe;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TableLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.kitchenkompanion.R;
import com.example.kitchenkompanion.Recipe;
import com.example.kitchenkompanion.databinding.FragmentRecipeBinding;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class RecipeFragment extends Fragment {

    private FragmentRecipeBinding binding;
    private RecipeViewModel recipeViewModel;

    private SearchView searchView;
    private HashSet currSearchStringSet;
    private ArrayAdapter<String> arrayAdapter;
    private ListView listView;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        recipeViewModel =
                new ViewModelProvider(this).get(RecipeViewModel.class);
        recipeViewModel.setActivity(getActivity());
        recipeViewModel.initTableLayout();

        binding = FragmentRecipeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // bind the table to the xml
        final TableLayout tableLayout = binding.shoppingListsTable;
        recipeViewModel.getTableLayout().observe(getViewLifecycleOwner(), tableLayout::addView);

        listView = root.findViewById(R.id.recipe_listview);
        listView.setVisibility(View.GONE);
        arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, createSearchStrings());
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(messageClickedHandler);

        return root;
    }

    // Create a message handling object as an anonymous class.
    private AdapterView.OnItemClickListener messageClickedHandler;
    {
        messageClickedHandler = new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // when click on row, populate search bar with term
                searchView.setQuery(((TextView) v).getText(), true);
            }
        };
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true); // It's important here
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();

        inflater.inflate(R.menu.recipe_menu, menu);
        MenuItem item = menu.findItem(R.id.action_search_recipe);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

        listView.setVisibility(View.GONE);
        searchView = (SearchView) item.getActionView();
        searchView.setQueryHint("Search for recipe");
        searchView.setMaxWidth(Integer.MAX_VALUE); // make it take the full header when open

        // set search query to saved search string
        searchView.post(new Runnable() {
            @Override
            public void run() {
                // Important! Make sure searchView has been initialized
                // and referenced to the correct (current) SearchView.
                // Config changes (e.g. screen rotation) may make the
                // variable value null.
                searchView.setQuery("", false);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                listView.setVisibility(View.GONE);
                recipeViewModel.setCurrFilters(createBase(query));
                searchView.clearFocus();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.length() == 0) {
                    listView.setVisibility(View.GONE);
                    recipeViewModel.setCurrFilters(null);
                } else {
                    listView.setVisibility(View.VISIBLE);
                    if (newText.charAt(newText.length()-1) == ' ') {
                        // make sure word is already in our search strings
                        if (currSearchStringSet.contains(newText.trim())) {
                            arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, createSearchStrings(createBase(newText.trim())));
                            listView.setAdapter(arrayAdapter);
                        }
                    }
                }
                arrayAdapter.getFilter().filter(newText);
                return true;
            }
        });

        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recipeViewModel.setCurrFilters(null);
                return false;
            }
        });
    }

    // create filter
    private HashSet<String> createBase(String text) {
        HashSet<String> base = new HashSet<>();
        for (String n : text.split(" "))
            base.add(n.toLowerCase());
        return base;
    }

    // create search strings (combo of names, diets, and difficulty)
    // like "easy chicken vegan"
    // assume createSearchStrings() was already called and inited search strings
    private List<String> createSearchStrings(HashSet<String> base) {
        String baseString = "";
        for (String b : base)
            baseString += b + " ";

        currSearchStringSet = new HashSet<>();
        for (Recipe recipe : recipeViewModel.getRecipes()) {
            if (recipe.getSearchStrings().containsAll(base)) {
                for (String searchString : recipe.getSearchStrings()) {
                    if (!base.contains(searchString))
                        currSearchStringSet.add(baseString + searchString);
                }
            }
        }
        ArrayList<String> l = new ArrayList<>();
        l.addAll(currSearchStringSet);
        return l;
    }

    // create search strings (names, diets, and difficulty)
    private List<String> createSearchStrings() {
        // so we don't get duplicates
        currSearchStringSet = new HashSet<>();
        for (Recipe recipe : recipeViewModel.getRecipes())
            currSearchStringSet.addAll(recipe.getSearchStrings());

        ArrayList<String> l = new ArrayList<>();
        l.addAll(currSearchStringSet);
        return l;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}