package com.example.kitchenkompanion.ui.shopping;

import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.navigation.fragment.NavHostFragment;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;


import com.example.kitchenkompanion.InventoryItem;
import com.example.kitchenkompanion.R;
import com.example.kitchenkompanion.ShoppingList;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.HashSet;
import java.util.List;

public class IndividualListFragment extends Fragment {

    private boolean clicked = false;
//    private Animation rotateOpen = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_open_anim);
//    private Animation rotateClose = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_close_anim);
//    private Animation fromBottom = AnimationUtils.loadAnimation(getContext(), R.anim.from_bottom_anim);
//    private Animation toBottom = AnimationUtils.loadAnimation(getContext(), R.anim.to_bottom_anim);


    private Animation rotateOpen;
    private Animation rotateClose;
    private Animation fromBottom;
    private Animation toBottom;

    FloatingActionButton expand_btn;
    FloatingActionButton add_btn;
    FloatingActionButton copy_btn;

    private static final int CHECKBOX_SIZE = 32;
    private static final int NAME_SIZE = 300;
    private static final int QUANTITY_SIZE = 200;
    private static final int DEFAULT_PADDING = 8;
    private static ShoppingList shoppingList;

    private TableLayout mTableLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root =  inflater.inflate(R.layout.fragment_individual_list, container, false);

        initData();

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(shoppingList.getName());
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        expand_btn = root.findViewById(R.id.expand_btn);
        add_btn = root.findViewById(R.id.add_item_btn);
        copy_btn = root.findViewById(R.id.copy_btn);

        rotateOpen = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_open_anim);
        rotateClose = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_close_anim);
        fromBottom = AnimationUtils.loadAnimation(getContext(), R.anim.from_bottom_anim);
        toBottom = AnimationUtils.loadAnimation(getContext(), R.anim.to_bottom_anim);

        expand_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onExpandClicked();
            }
        });

        mTableLayout = root.findViewById(R.id.individual_items_table);

        createTable(shoppingList.getItems());

        return root;
    }

    private void onExpandClicked(){
        setVisibility();
        setAnimation();
        clicked = !clicked;
    }

    private void setVisibility(){
        if (!clicked){
            add_btn.setVisibility(View.VISIBLE);
            copy_btn.setVisibility(View.VISIBLE);
        }
        else{
            add_btn.setVisibility(View.INVISIBLE);
            copy_btn.setVisibility(View.INVISIBLE);
        }
    }

    private void setAnimation(){
        if (!clicked){
            add_btn.startAnimation(fromBottom);
            copy_btn.startAnimation(fromBottom);
            expand_btn.startAnimation(rotateOpen);
        }
        else{
            add_btn.startAnimation(toBottom);
            copy_btn.startAnimation(toBottom);
            expand_btn.startAnimation(rotateClose);
        }
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavHostFragment.findNavController(this).popBackStack();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();

        inflater.inflate(R.menu.individual_list_menu, menu);

    }

    // pull shopping list data from static field
    private void initData() {
        shoppingList = ShoppingViewModel.currentShoppingList;
    }

    private void createTable(List<InventoryItem> items) {
        mTableLayout.removeAllViews();
        createHeaderRow();
        createTableRows(items);
    }

    private void createTableRows(List<InventoryItem> items) {
        for (InventoryItem item : items) {
            addTableRow(item);
        }
    }

    // Create a header row for table
    private void createHeaderRow() {
        /* Create a new row to be added. */
        TableRow tr = new TableRow(getActivity());
        tr.setBackground(getActivity().getResources().getDrawable(R.drawable.list_item_white));
        tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        tr.setId(tr.generateViewId());
        tr.setPadding(DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING);

        CheckBox cbSelected = new CheckBox(getActivity());
        setCheckboxSettings(cbSelected, CHECKBOX_SIZE);
        if (shoppingList.getSelected().size() == shoppingList.getItems().size() && shoppingList.getSelected().size() != 0)
            cbSelected.setChecked(true);
        else
            cbSelected.setChecked(false);
        cbSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox cb = (CheckBox) v;
                if(cb.isChecked())
                    shoppingList.getSelected().addAll(shoppingList.getItems());
                else
                    shoppingList.getSelected().clear();
                createTable(shoppingList.getItems());
            }
        });

        tr.addView(cbSelected);

        /* Create a TextView to be the row-content. */
        TextView tvName = new TextView(getActivity());
        String nameText = "Name";
        setTextViewSettings(tvName, nameText, NAME_SIZE, true);
        tr.addView(tvName);

        /* Create a TextView to be the row-content. */
        TextView tvQuantity = new TextView(getActivity());
        setTextViewSettings(tvQuantity, "Quantity", QUANTITY_SIZE, true);
        tr.addView(tvQuantity);

        mTableLayout.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));
    }

    // settings for checkbox
    private void setCheckboxSettings(CheckBox cb, int maxWidth) {
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams();
        layoutParams.gravity = Gravity.CENTER_VERTICAL;
        cb.setLayoutParams(layoutParams);
        cb.setMaxWidth(maxWidth);
        cb.setPadding(DEFAULT_PADDING, 0, DEFAULT_PADDING, 0);
    }

    // Create a textview with proper settings
    private void setTextViewSettings(TextView textView, String text, int maxWidth, boolean bold) {
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams();
        layoutParams.gravity = Gravity.CENTER_VERTICAL;
        textView.setLayoutParams(layoutParams);
        textView.setMaxWidth(maxWidth);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setMaxLines(4);
        textView.setTextSize(getActivity().getResources().getInteger(R.integer.table_entry));
        textView.setText(text);
        if (bold) textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(DEFAULT_PADDING, 0, DEFAULT_PADDING, 0);
    }


    private void addTableRow(InventoryItem item) {
        /* Create a new row to be added. */
        TableRow tr = new TableRow(getActivity());

        tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        tr.setBackground(getActivity().getResources().getDrawable(R.drawable.list_item_white));
        tr.setPadding(DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING);

        addRowElements(tr, item, false);
        mTableLayout.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));
    }


    // Create 4 textviews for each row
    private void addRowElements(TableRow tr, InventoryItem item, boolean bold) {

        String name = item.getName();
        if (!item.getOwner().equals(InventoryItem.DEFAULT_OWNER))
            name += " (" + item.getOwner() + ")";

        String quantity = "";
        if ((int) item.getQuantity() == item.getQuantity())
            // can be represented as int, so do that
            quantity += String.valueOf((int) item.getQuantity());
        else
            quantity += String.valueOf(item.getQuantity());
        if (!item.getUnit().equals("#"))
            quantity += " " + item.getUnit();

        CheckBox cbSelected = new CheckBox(getActivity());
        setCheckboxSettings(cbSelected, CHECKBOX_SIZE);
        tr.addView(cbSelected);

        /* Create a TextView to be the row-content. */
        TextView tvName = new TextView(getActivity());
        setTextViewSettings(tvName, name, NAME_SIZE, bold);
        tr.addView(tvName);

        /* Create a TextView to be the row-content. */
        TextView tvQuantity = new TextView(getActivity());
        setTextViewSettings(tvQuantity, quantity, QUANTITY_SIZE, bold);
        tr.addView(tvQuantity);

        if (shoppingList.getSelected().contains(item)) {
            cbSelected.setChecked(true);
            tvName.setPaintFlags(tvName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            tvQuantity.setPaintFlags(tvQuantity.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            tvName.setPaintFlags(0);
            tvQuantity.setPaintFlags(0);
        }
        // if the checkbox is clicked, update state & strikethrough
        cbSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox cb = (CheckBox) v;
                if(cb.isChecked()) {
                    shoppingList.getSelected().add(item);
                    tvName.setPaintFlags(tvName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                    tvQuantity.setPaintFlags(tvQuantity.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                }
                else {
                    shoppingList.getSelected().remove(item);
                    tvName.setPaintFlags(0);
                    tvQuantity.setPaintFlags(0);
                }
            }
        });
    }

}