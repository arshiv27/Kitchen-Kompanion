package com.example.kitchenkompanion;

import android.os.Bundle;
import android.view.Menu;

import com.example.kitchenkompanion.ui.inventory.CreateItemDialogFragment;
import com.example.kitchenkompanion.ui.inventory.EditItemDialogFragment;
import com.example.kitchenkompanion.ui.inventory.InventoryFragment;
import com.example.kitchenkompanion.ui.inventory.InventoryViewModel;
import com.example.kitchenkompanion.ui.recipe.RecipeDialogFragment;
import com.example.kitchenkompanion.ui.recipe.RecipeFragment;
import com.example.kitchenkompanion.ui.shopping.CreateListDialogFragment;
import com.example.kitchenkompanion.ui.shopping.ShoppingViewModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.fragment.app.Fragment;

import com.example.kitchenkompanion.databinding.ActivityMainBinding;

import java.util.List;

public class MainActivity extends AppCompatActivity implements CreateItemDialogFragment.CreateItemDialogListener,
        EditItemDialogFragment.EditItemDialogListener, RecipeDialogFragment.RecipeDialogListener, CreateListDialogFragment.CreateListDialogListener {

    private ActivityMainBinding binding;
    private InventoryViewModel inventoryViewModel;
    private ShoppingViewModel shoppingViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_recipe, R.id.navigation_inventory, R.id.navigation_shopping, R.id.individualListFragment)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);
        System.out.println("Hit Main");
        inventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);
        shoppingViewModel = new ViewModelProvider(this).get(ShoppingViewModel.class);
        shoppingViewModel.setActivity(this);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_activity_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // The dialog fragment receives a reference to this Activity through the
    // Fragment.onAttach() callback, which it uses to call the following methods
    // defined by the NoticeDialogFragment.NoticeDialogListener interface
    @Override
    public void onDialogPositiveClick(DialogFragment dialog) {
        if (dialog instanceof CreateItemDialogFragment) {
            CreateItemDialogFragment cDialog = (CreateItemDialogFragment) dialog;
            // do we already combine with existing or do we need to add a new entry?
            if (!cDialog.getCombineItem())
                inventoryViewModel.addInventoryItem(cDialog.getItem());
            // refresh the screen
            inventoryViewModel.refreshTable();
        } else if (dialog instanceof EditItemDialogFragment) {
            EditItemDialogFragment eDialog = (EditItemDialogFragment) dialog;
            // do we already combine with existing and need to delete entry?
            if (eDialog.getCombineItem())
                inventoryViewModel.removeInventoryItem(eDialog.getItem());

//            inventoryViewModel.editInventoryItem(eDialog.getItem(), eDialog.getRowIndex());
            // eDialog.getItem() object is SAME object in inventory items list.
            // we just need to refresh the screen
            inventoryViewModel.refreshTable();

        } else if (dialog instanceof RecipeDialogFragment) {
            RecipeDialogFragment rDialog = (RecipeDialogFragment) dialog;
            List<InventoryItem> missingIngredients = rDialog.getMissingIngredients();
            if (missingIngredients.isEmpty()) {
                // deduct from inventory
                System.out.println("Deduct from inventory");
                inventoryViewModel.removeMultipleInventoryItems(rDialog.getRecipe().getIngredients());
            } else {
                // add missing to shopping list
                for (InventoryItem ingredient : missingIngredients) {
                    System.out.println("Need " + ingredient.toString());
                }
            }
        }
        else if (dialog instanceof CreateListDialogFragment){
            CreateListDialogFragment cDialog = (CreateListDialogFragment) dialog;
            shoppingViewModel.addShoppingList(cDialog.getShoppingList());
        }
    }

    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {
        if (dialog instanceof CreateItemDialogFragment) {
            System.out.println("shouldnt happen");
        } else if (dialog instanceof EditItemDialogFragment) {
            EditItemDialogFragment eDialog = (EditItemDialogFragment) dialog;
            inventoryViewModel.removeInventoryItem(eDialog.getItem());
        } else if (dialog instanceof RecipeDialogFragment) {
            System.out.println("negative");
        }
        else if (dialog instanceof CreateListDialogFragment) {
            System.out.println("negative");
        }

    }

    @Override
    public void onDialogNeutralClick(DialogFragment dialog) {
        if (dialog instanceof CreateItemDialogFragment) {
            System.out.println("canceled");
        } else if (dialog instanceof EditItemDialogFragment) {
            System.out.println("canceled");
        } else if (dialog instanceof RecipeDialogFragment) {
            System.out.println("canceled");
        }
        else if (dialog instanceof CreateListDialogFragment) {
            System.out.println("canceled");
        }

    }



}