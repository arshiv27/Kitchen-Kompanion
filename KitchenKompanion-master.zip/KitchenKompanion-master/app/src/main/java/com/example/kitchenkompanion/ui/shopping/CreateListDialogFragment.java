package com.example.kitchenkompanion.ui.shopping;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;


import com.example.kitchenkompanion.R;
import androidx.fragment.app.DialogFragment;
import com.example.kitchenkompanion.ShoppingList;

import java.time.LocalDate;
import java.util.ArrayList;

public class CreateListDialogFragment extends DialogFragment {
    public static String TAG = "CreateListDialog";
    private static String ASTRIX = "<font color=\"#ff0000\">" + "* " + "</font>";
    private ShoppingList shoppingList;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){
       // Use Builder class for convenient dialog construction
       AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

       View view = getActivity().getLayoutInflater().inflate(R.layout.create_shopping_list_dialog, null);

        // Set Text field in dialog
        ((TextView) view.findViewById(R.id.list_name_text)).setText(Html.fromHtml( "Shopping List Name  " + ASTRIX));

        // Retrieve the Edit Text Field
        EditText listName = (EditText) view.findViewById(R.id.list_name);
        listName.setHint("Enter here");


        builder.setTitle("Add a new list")
                .setView(view)
                .setPositiveButton("Save", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        //Do nothing here because we override this button later to change the close behaviour.
                        //However, we still need this because on older versions of Android unless we
                        //pass a handler the button doesn't get instantiated
                    }
                })
                .setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Send the negative button event back to the host activity
                        listener.onDialogNeutralClick(CreateListDialogFragment.this);

                    }
                });



        // overwrite the positive button functionality
        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // parse data
                String name = listName.getText().toString();

                // check conditions
                if (!name.equals("") && !name.trim().isEmpty()) {
                    // create new shopping list

                    shoppingList = new ShoppingList(name, LocalDate.now(), new ArrayList<>());
                    listener.onDialogPositiveClick(CreateListDialogFragment.this);
                    dialog.dismiss();
                } else {
                    // TODO message user that fields are invalid
                    System.out.println("Invalid!");
                }
            }
        });

        return dialog;
    }

    /* The activity that creates an instance of this dialog fragment must
     * implement this interface in order to receive event callbacks.
     * Each method passes the DialogFragment in case the host needs to query it. */
    public interface CreateListDialogListener {
        public void onDialogPositiveClick(DialogFragment dialog);
        public void onDialogNegativeClick(DialogFragment dialog);
        public void onDialogNeutralClick(DialogFragment dialog);
    }

    // Use this instance of the interface to deliver action events
    CreateListDialogListener listener;

    // Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            listener = (CreateListDialogListener) context;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException("must implement CreateListDialogListener");
        }
    }

    public ShoppingList getShoppingList() {
        return shoppingList;
    }


}
