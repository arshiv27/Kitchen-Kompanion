package com.example.kitchenkompanion;

import static java.time.temporal.ChronoUnit.DAYS;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;

public class InventoryItem implements Serializable {
    public static final String DEFAULT_OWNER = "me";
    public static final String DEFAULT_SHARED_OWNER = "shared";
    public static ArrayList<String> LOCATIONS = new ArrayList<String> (Arrays.asList("fridge", "pantry", "cabinet"));
    public static ArrayList<String> UNITS = new ArrayList<String> (Arrays.asList("#", "lbs", "gal", "fl", "cup", "tbsp", "tsp"));
    public static ArrayList<String> OWNERS = new ArrayList<String> (Arrays.asList(DEFAULT_OWNER, DEFAULT_SHARED_OWNER, "bill", "bobby"));

    private String name;
    private String owner;
    private double quantity;
    private String location;
    private LocalDate exprDate;
    private String unit;

    private HashSet<String> searchStrings;

    public InventoryItem(String name, String owner, double quantity, String location, LocalDate exprDate, String unit) {
        this.name = name.toLowerCase();
        this.owner = owner.toLowerCase();
        this.quantity = quantity;
        this.location = location.toLowerCase();
        this.exprDate = exprDate;
        this.unit = unit.toLowerCase();

        updateSearchStrings();
    }

    private void updateSearchStrings() {
        // add filter results
        searchStrings = new HashSet<>();
        for (String n : name.split(" "))
            searchStrings.add(n.toLowerCase());
        searchStrings.add(name.toLowerCase());
        searchStrings.add(location.toLowerCase());
        searchStrings.add(owner.toLowerCase());
        searchStrings.add(unit.toLowerCase());
    }

    public InventoryItem(String name, String owner, double quantity) {
        this(name, owner, quantity, "fridge", LocalDate.now(), "#");
    }

    public InventoryItem(String name, String owner, double quantity, String unit) {
        this(name, owner, quantity, "fridge", LocalDate.now(),  unit);
    }

    public InventoryItem(String name, double quantity, String unit) {
        this(name, DEFAULT_OWNER, quantity, "fridge", LocalDate.now(), unit);
    }

    public InventoryItem(String name, double quantity) {
        this(name, DEFAULT_OWNER, quantity, "fridge", LocalDate.now(), "#");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        updateSearchStrings();
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
        updateSearchStrings();

    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object o) {
        return o == this;
//        if (o == this)
//            return true;
//        if (!(o instanceof InventoryItem))
//            return false;
//        InventoryItem other = (InventoryItem) o;
//        return this.name.toLowerCase().equals(other.getName().toLowerCase()) &&
//                this.owner.toLowerCase().equals(other.getOwner().toLowerCase());
    }

    public boolean compareDefiningFields(InventoryItem other) {
        boolean nameOwnerMatch = this.name.equalsIgnoreCase(other.getName()) &&
                this.owner.equalsIgnoreCase(other.getOwner());
        boolean locationMatch = (this.location == null && other.getExprDate() == null) || (this.location.equalsIgnoreCase(other.getLocation()));
        boolean exprDateMatch = (this.exprDate == null && other.getExprDate() == null) || (this.location.equals(other.getExprDate()));
        return nameOwnerMatch && locationMatch && exprDateMatch && this != other;
    }

    public boolean combineItems(InventoryItem other) {
        if (compareDefiningFields(other)) {
            this.quantity += other.getQuantity();
            return true;
        } else
            return false;
    }

    @Override
    public final int hashCode() {
        return (name.toLowerCase() + " " + owner.toLowerCase()).hashCode();
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
        updateSearchStrings();
    }

    public LocalDate getExprDate() {
        return exprDate;
    }

    public void setExprDate(LocalDate exprDate) {
        this.exprDate = exprDate;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
        updateSearchStrings();
    }

    public HashSet<String> getSearchStrings() {
        return searchStrings;
    }

    public String toString() {
        return name + " " + quantity + " " + owner;
    }

    public boolean nearExpiration() {
        boolean ret = false;
        if (exprDate != null) {
            // check if item is within 3 days of expiration (but not expired)
            long daysBetween = DAYS.between(LocalDate.now(), exprDate);
            // 0 <= x <= 3
            ret = 0 <= daysBetween && daysBetween <= 3;

        }
        return ret;
    }

    public boolean expired() {
        boolean ret = false;
        if (exprDate != null) {
            // check if item is within 3 days of expiration (but not expired)
            long daysBetween = DAYS.between(exprDate, LocalDate.now());
            ret = daysBetween > 0;
        }
        return ret;
    }
}
