package com.example.kitchenkompanion.ui.inventory;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

import com.example.kitchenkompanion.CommonIngredients;
import com.example.kitchenkompanion.InventoryItem;
import com.example.kitchenkompanion.R;

import java.time.LocalDate;
import java.util.ArrayList;

public class EditItemDialogFragment extends DialogFragment {

    public static String TAG = "EditItemDialog";
    private static String ASTRIX = "<font color=\"#ff0000\">" + "* " + "</font>";
    private InventoryItem item;
    private int rowIndex;
    private boolean combineItem;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Bundle bundle = getArguments();
        item = (InventoryItem) bundle.getSerializable("item");
        rowIndex = bundle.getInt("row_index");

        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        View view = getActivity().getLayoutInflater().inflate(R.layout.create_item_dialog, null);

        // Set lefthand-side text
        ((TextView) view.findViewById(R.id.item_name_text)).setText(Html.fromHtml ( "Item " + ASTRIX));
        ((TextView) view.findViewById(R.id.item_quantity_text)).setText(Html.fromHtml ( "Quantity " + ASTRIX));
        ((TextView) view.findViewById(R.id.item_unit_text)).setText(Html.fromHtml ( "Unit "));
        ((TextView) view.findViewById(R.id.item_owner_text)).setText(Html.fromHtml ( "Owner " + ASTRIX));
        ((TextView) view.findViewById(R.id.item_expr_date_text)).setText(Html.fromHtml ( "Expr Date "));
        ((TextView) view.findViewById(R.id.item_location_text)).setText(Html.fromHtml ( "Location "));

        // Get autocompletes
        AutoCompleteTextView actvName = (AutoCompleteTextView) view.findViewById(R.id.item_name);
        ArrayAdapter<String> arrayAdapterName = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, CommonIngredients.COMMON_INGREDIENTS.toArray(new String[0]));
        actvName.setAdapter(arrayAdapterName);
        actvName.setThreshold(1);
        actvName.setText(item.getName());

        AutoCompleteTextView actvOwner = (AutoCompleteTextView) view.findViewById(R.id.item_owner);
        ArrayAdapter<String> arrayAdapterOwner = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, InventoryItem.OWNERS);
        actvOwner.setAdapter(arrayAdapterOwner);
        actvOwner.setThreshold(1);
        actvOwner.setText(item.getOwner());

        AutoCompleteTextView actvLocation = (AutoCompleteTextView) view.findViewById(R.id.item_location);
        ArrayAdapter<String> arrayAdapterLocation = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, InventoryItem.LOCATIONS);
        actvLocation.setAdapter(arrayAdapterLocation);
        actvLocation.setThreshold(1);
        if (!item.getLocation().equals("")) {
            actvLocation.setText(item.getLocation());
        } else {
            actvLocation.setOnTouchListener(new View.OnTouchListener(){
                @Override
                public boolean onTouch(View v, MotionEvent event){
                    actvLocation.showDropDown();
                    return false;
                }
            });
        }

        // Get edit texts
        EditText etQuantity = (EditText) view.findViewById(R.id.item_quantity_edit);
        etQuantity.setText(formatQuantity(item.getQuantity()));
        ((LinearLayout) view.findViewById(R.id.item_quantity_layout_edit)).setVisibility(View.VISIBLE);

        // expr date is text with button so set to text
        //EditText etExprDate = (EditText) view.findViewById(R.id.item_expr_date);
        TextView etExprDate = (TextView) view.findViewById(R.id.item_expr_set_date);
        if (item.getExprDate() != null) etExprDate.setText(item.getExprDate().toString());
        else etExprDate.setText("Missing Date");

        // Get spinners
        Spinner spUnit = (Spinner) view.findViewById(R.id.item_unit);
        ArrayAdapter<String> arrayAdapterUnit = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, InventoryItem.UNITS);
        spUnit.setAdapter(arrayAdapterUnit);
        spUnit.setSelection(InventoryItem.UNITS.indexOf(item.getUnit()));

        ((TextView) view.findViewById(R.id.item_invalid)).setVisibility(View.GONE);

        builder.setTitle("Edit item")
                .setView(view)
                .setPositiveButton("Save", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        //Do nothing here because we override this button later to change the close behaviour.
                        //However, we still need this because on older versions of Android unless we
                        //pass a handler the button doesn't get instantiated
                    }
                }).setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Send the negative button event back to the host activity
                        listener.onDialogNeutralClick(EditItemDialogFragment.this);
                    }
                })
                .setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Send the negative button event back to the host activity

                    }
                });

        // set up +/- buttons for quantity
        Button minus = (Button) view.findViewById(R.id.button_minus);
        Button plus = (Button) view.findViewById(R.id.button_plus);
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double curr = Double.parseDouble(etQuantity.getText().toString());
                if (curr > 1) {
                    etQuantity.setText(formatQuantity(curr - 1));
                    item.setQuantity(curr - 1);
                }
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double curr = Double.parseDouble(etQuantity.getText().toString());
                etQuantity.setText(formatQuantity(curr + 1));
                item.setQuantity(curr+1);
            }
        });

        // overwrite the positive button functionality
        final AlertDialog dialog = builder.create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getActivity().getColor(R.color.red));
            }
        });
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((TextView) view.findViewById(R.id.item_invalid)).setVisibility(View.GONE);
                // parse data
                String name = actvName.getText().toString();
                String quantity = etQuantity.getText().toString();
                String unit = spUnit.getSelectedItem().toString();
                String owner = actvOwner.getText().toString();
                String exprDateString = etExprDate.getText().toString();
                String location = actvLocation.getText().toString();
                LocalDate exprDate = null; // TODO

                // check conditions
                if (!name.equals("") && !quantity.equals("") && !owner.equals("") && (Double.parseDouble(quantity) > 0)) {
                    // create new item
                    // TODO dates
                    item.setName(name);
                    item.setOwner(owner);
                    item.setQuantity(Double.parseDouble(quantity));
                    item.setUnit(unit);
                    item.setExprDate(exprDate);
                    item.setLocation(location);

                    // if new item name, add it to list of items
                    if (!CommonIngredients.COMMON_INGREDIENTS.contains(name))
                        CommonIngredients.COMMON_INGREDIENTS.add(name);

                    // if new owner name, add it to list of names
                    if (!InventoryItem.OWNERS.contains(owner))
                        InventoryItem.OWNERS.add(owner);

                    // if new location name, add it to list of names
                    if (!location.equals("") && !InventoryItem.LOCATIONS.contains(location))
                        InventoryItem.LOCATIONS.add(location);

                    InventoryItem matched = InventoryViewModel.matchInInventoryItems(item);
                    if (matched != null) {
                        // new item matches existing item. ask if want to combine
                        String msg = "You already have " + formatQuantity(matched.getQuantity()) + " ";
                        if (!matched.getUnit().equals("#")) {
                            msg += matched.getUnit() + " ";
                        }
                        msg += name + "(s) in your ";
                        if (!matched.getLocation().equals(""))
                            msg += matched.getLocation();
                        else
                            msg += "inventory";
                        if (!exprDateString.equals("")) {
                            msg += " expiring on " + exprDateString;
                        }
                        msg += ". Would you like to combine the entries?";

                        AlertDialog combinePopupDialog = new AlertDialog.Builder(getActivity())
                                .setTitle("Combine matching items?")
                                .setMessage(msg)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface innerDialog, int whichButton) {
                                        combineItem = true;
                                        matched.combineItems(item);
                                        listener.onDialogPositiveClick(EditItemDialogFragment.this);
                                        dialog.dismiss();
                                    }})
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface innerDialog, int whichButton) {
                                        combineItem = false;
                                        listener.onDialogPositiveClick(EditItemDialogFragment.this);
                                        dialog.dismiss();
                                    }})
                                .setNeutralButton("Cancel", null).create();
                        combinePopupDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                            @Override
                            public void onShow(DialogInterface dialogInterface) {
                                combinePopupDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getActivity().getColor(R.color.red));
                            }
                        });
                        combinePopupDialog.show();
                    } else {
                        // not matching any existing item
                        listener.onDialogPositiveClick(EditItemDialogFragment.this);
                        dialog.dismiss();
                    }
                } else {
                    // TODO message user that fields are invalid
                    TextView invalid = ((TextView) view.findViewById(R.id.item_invalid));
                    ArrayList<String> invalidFields = new ArrayList<>();
                    if (name.equals(""))
                        invalidFields.add("item");
                    if (quantity.equals(""))
                        invalidFields.add("quantity");
                    if (owner.equals(""))
                        invalidFields.add("owner");

                    String msg;
                    if (invalidFields.size() == 1) {
                        msg = "Please fill in " + invalidFields.get(0) + ".";
                    } else if (invalidFields.size() == 2) {
                        msg = "Please fill in " + invalidFields.get(0) + " and " + invalidFields.get(1) + ".";
                    } else if (invalidFields.size() == 3) {
                        msg = "Please fill in " + invalidFields.get(0) + ", " + invalidFields.get(1) + ", and " + invalidFields.get(2) + ".";
                    } else {
                        // quantity less than 0;
                        msg = "Invalid quantity, must be greater than 0.";
                    }
                    invalid.setText(msg);
                    invalid.setTextColor(getActivity().getColor(R.color.red));
                    invalid.setVisibility(View.VISIBLE);
                }
            }
        });

        // create confirmation message for deletion
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = actvName.getText().toString();
                String owner = actvOwner.getText().toString();

                // create alert message
                String msg = "This action will remove ";
                if (owner.equals(InventoryItem.DEFAULT_OWNER))
                    msg += "your";
                else
                    msg += owner + "'s";
                msg += " \"" + name + "\" from the inventory.";

                new AlertDialog.Builder(getActivity())
                        .setTitle("Are you sure?")
                        .setMessage(msg)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface innerDialog, int whichButton) {
                                listener.onDialogNegativeClick(EditItemDialogFragment.this);
                                dialog.dismiss();
                            }})
                        .setNeutralButton("Cancel", null).show();
            }
        });

        // Create the AlertDialog object and return it
        return dialog;
    }

    private String formatQuantity(double quantity) {
        if ((int) quantity == quantity) {
            // can be represented as int
            return String.valueOf((int) quantity);
        } else
            return String.valueOf(quantity);
    }


    /* The activity that creates an instance of this dialog fragment must
     * implement this interface in order to receive event callbacks.
     * Each method passes the DialogFragment in case the host needs to query it. */
    public interface EditItemDialogListener {
        public void onDialogPositiveClick(DialogFragment dialog);
        public void onDialogNegativeClick(DialogFragment dialog);
        public void onDialogNeutralClick(DialogFragment dialog);
    }

    // Use this instance of the interface to deliver action events
    EditItemDialogListener listener;

    // Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            listener = (EditItemDialogListener) context;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException("must implement EditItemDialogListener");
        }
    }

    public InventoryItem getItem() {
        return item;
    }

    public boolean getCombineItem() {
        return combineItem;
    }


    public int getRowIndex() { return rowIndex; }
}