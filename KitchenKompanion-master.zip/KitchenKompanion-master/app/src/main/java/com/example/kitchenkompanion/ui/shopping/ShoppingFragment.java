package com.example.kitchenkompanion.ui.shopping;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TableLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.Nullable;

import com.example.kitchenkompanion.R;
import com.example.kitchenkompanion.databinding.FragmentShoppingBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class ShoppingFragment extends Fragment {

    public static  String TAG = "ShoppingFragment";
    private ShoppingViewModel shoppingViewModel;
    private FragmentShoppingBinding binding;

    FloatingActionButton fab;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        System.out.println("Hit ShoppingList");
        // Get Shopping View Model
        ShoppingViewModel shoppingViewModel =
                new ViewModelProvider(this).get(ShoppingViewModel.class);

        // initialize the activity (work around to provide fragment activity to view model)
        shoppingViewModel.setActivity(getActivity());

        //initialize Table Layout in fragment
        shoppingViewModel.initTableLayout();

        binding = FragmentShoppingBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        shoppingViewModel.setView(root);
        // bind table to XML
        final TableLayout tableLayout = binding.shoppingListTableLayout;
        shoppingViewModel.getTableLayout().observe(getViewLifecycleOwner(), tableLayout::addView);

        fab = root.findViewById(R.id.floatingAddButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ToDo: Implement Pop-Up
                CreateListDialogFragment createListDialogFragment = new CreateListDialogFragment();
                createListDialogFragment.show(getChildFragmentManager(), CreateListDialogFragment.TAG);
            }
        });


        return root;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true); // It's important here
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();

        inflater.inflate(R.menu.shopping_menu, menu);
        MenuItem item = menu.findItem(R.id.action_search_shopping);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

        SearchView searchView = (SearchView) item.getActionView();
        searchView.setQueryHint("Search for shopping list");
        searchView.setMaxWidth(Integer.MAX_VALUE); // make it take the full header when open

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Here is where we are going to implement the filter logic
                return true;
            }

        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}