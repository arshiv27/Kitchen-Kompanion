package com.example.kitchenkompanion.ui.recipe;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.kitchenkompanion.InventoryItem;
import com.example.kitchenkompanion.R;
import com.example.kitchenkompanion.Recipe;
import com.example.kitchenkompanion.ui.inventory.InventoryViewModel;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

public class RecipeViewModel extends ViewModel {

    public MutableLiveData<TableLayout> mTableLayout;
    public MutableLiveData<List<Recipe>> recipes;
    public MutableLiveData<List<Recipe>> currRecipes;
    private MutableLiveData<HashSet<String>> currFilters;
    private androidx.fragment.app.FragmentActivity activity;
    public static final int FAVORITE_SIZE = 48;
    public static final int NAME_SIZE = 152;
    public static final int DIET_SIZE = 96;
    public static final int IMAGE_SIZE = 180;
    private static final int DEFAULT_PADDING = 8;

    private enum SortOrder {NAME_ASC, NAME_DSC }
    private MutableLiveData<RecipeViewModel.SortOrder> sortOrder;

    // TODO
    // Important: this is a sketchy get-around to provide activity to view model
    // so that we can create dynamic xml elements.
    // ONLY ASSIGN ONCE
    public void setActivity(androidx.fragment.app.FragmentActivity activity) {
        this.activity = activity;
    }

    public RecipeViewModel() {
        mTableLayout = new MutableLiveData<>();
        sortOrder = new MutableLiveData<>();
        sortOrder.setValue(RecipeViewModel.SortOrder.NAME_ASC);
        loadDefaultRecipes();
    }

    private void loadDefaultRecipes() {
        recipes = new MutableLiveData<List<Recipe>>();
        currRecipes = new MutableLiveData<List<Recipe>>();
        currFilters = new MutableLiveData<>();
        recipes.setValue(new ArrayList<Recipe>());

        // https://tasty.co/recipe/easy-chicken-piccata#.gyWLwBEDN
        // ingredients
        InventoryItem[] chickenPiccataIngredients = {
                new InventoryItem("Chicken Breast", 1),
                new InventoryItem("Salt", Recipe.NEGLIGIBLE_QUANTITY),
                new InventoryItem("Pepper", Recipe.NEGLIGIBLE_QUANTITY),
                new InventoryItem("Flour", Recipe.NEGLIGIBLE_QUANTITY),
                new InventoryItem("Butter",3, "tbsp"),
                new InventoryItem("Chicken Broth", 1, "cup"),
                new InventoryItem("Lemon", 1),
                new InventoryItem("Caper", 2, "tbsp")
        };
        String[] chickenPiccataSteps = {
                "Butterfly the chicken breast and pound it thin. Salt and pepper to taste.",
                "Dredge each piece in flour, shaking off the excess.",
                "In a skillet over high heat, melt three Tbsp. butter, and brown the chicken, the browner and crispier the better, 3–5 minutes on each side.",
                "Remove chicken from the skillet, and, in the same pan, add chicken stock, lemon, and capers.",
                "Boil until the sauce reduces by ⅓, and return the chicken to the skillet.",
                "Spoon sauce over the chicken several times.",
                "Serve immediately, with the remaining sauce poured over the chicken.",
                "Enjoy!"
        };
        Recipe chickenPiccata = new Recipe("Chicken Piccata", "Easy", 2,
                chickenPiccataIngredients, chickenPiccataSteps, false,
                R.drawable.chicken_piccata, 30, null);

        // https://tasty.co/recipe/garlic-parmesan-chicken-tenders
        InventoryItem[] parmesanChickenTendersIngredients = {
                new InventoryItem("Chicken Tender", 10),
                new InventoryItem("Flour", 1, "cup"),
                new InventoryItem("Lemon", 1),
                new InventoryItem("Panko", 1, "cup"),
                new InventoryItem("Parmesan Cheese", 1, "cup"),
                new InventoryItem("Garlic Powder", 1, "tbsp"),
                new InventoryItem("Salt", Recipe.NEGLIGIBLE_QUANTITY),
                new InventoryItem("Pepper", Recipe.NEGLIGIBLE_QUANTITY),
                new InventoryItem("Olive Oil", Recipe.NEGLIGIBLE_QUANTITY)
        };
        String[] parmesanChickenTendersSteps = {
                "Preheat oven to 425°F (220°C).",
                "Combine the egg and the lemon juice.",
                "In a separate bowl, combine the panko bread crumbs, Parmesan, garlic powder, lemon zest, salt, and pepper.",
                "Coat the chicken tenders in flour and shake off any excess. Then dredge in the egg and lemon juice mixture and allow excess egg to drip off. Coat with the panko bread crumb mixture, turning until evenly coated.",
                "Lay chicken tenders flat on a baking sheet lined with aluminum foil and sprayed with nonstick cooking spray. Spray additional cooking spray over the chicken tenders to help them brown.",
                "Bake for 20-25 minutes (or until browned and chicken is cooked all the way through), flipping once halfway through.",
                "Serve with your favorite dip and some veggies for a fun appetizer or with garlic Parmesan roasted vegetables for dinner!",
                "Enjoy!"
        };
        Recipe parmesanChickenTenders = new Recipe("Parmesan Chicken Tenders", "Medium", 2,
                parmesanChickenTendersIngredients, parmesanChickenTendersSteps, false,
                R.drawable.parmesan_chicken_tenders, 30, null);

        // https://tasty.co/recipe/the-fluffiest-vegan-pancakes
        InventoryItem[] veganPancakesIngredients = {
                new InventoryItem("Flour", 1, "cup"),
                new InventoryItem("Sugar", 2, "tbsp"),
                new InventoryItem("Baking Powder", 1, "tbsp"),
                new InventoryItem("Oat Milk", 1, "cup"),
                new InventoryItem("Apple Cider Vinegar", 1, "tbsp"),
                new InventoryItem("Vanilla", 1, "tsp"),
                new InventoryItem("Salt", Recipe.NEGLIGIBLE_QUANTITY),
                new InventoryItem("Maple Syrup", Recipe.NEGLIGIBLE_QUANTITY)
        };
        String[] veganPancakesSteps = {
                "In a medium bowl, add the flour, sugar, baking powder, and salt, and stir to combine.",
                "In a medium bowl or liquid measuring cup, add almond milk, apple cider vinegar, and vanilla, and stir to combine.",
                "Pour the liquid mixture into the dry mixture and whisk until smooth.",
                "Let batter rest for 5 minutes.",
                "Pour about ½ cup (65 grams) of batter onto a nonstick pan or griddle over medium heat.",
                "When the top begins to bubble, flip the pancake and cook until golden.",
                "Serve warm with maple syrup.",
                "Enjoy!"
        };
        Recipe veganPancakes = new Recipe("Pancakes", "Easy", 4,
                veganPancakesIngredients, veganPancakesSteps, false,
                R.drawable.vegan_pancakes, 20, new String[] {"Vegan", "Keto"});

        // https://tasty.co/recipe/chickpea-sweet-potato-stew
        InventoryItem[] chickpeaStewIngredients = {
                new InventoryItem("Coconut Oil", 2, "tbsp"),
                new InventoryItem("Onion", 1),
                new InventoryItem("Garlic Cloves", 3),
                new InventoryItem("Ginger", 1, "tsp"),
                new InventoryItem("Cumin", 1, "tsp"),
                new InventoryItem("Coriander", 1, "tsp"),
                new InventoryItem("Cayenne", 1, "tsp"),
                new InventoryItem("Chickpeas", 15, "oz"),
                new InventoryItem("Sweet Potato", 2),
                new InventoryItem("Vegetable Broth", 3, "cup"),
                new InventoryItem("Spinach", 5, "oz"),
        };
        String[] chickpeaStewSteps = {
                "In large pot or Dutch oven, heat the coconut oil over medium heat. Once the oil begins to shimmer, add the onion and cook for 4-5 minutes, or until the onion is semi-translucent.",
                "Add the garlic and ginger, and cook for 2-3 more minutes, until fragrant. Then add the sweet paprika, cumin, coriander, and cayenne and cook for 2 more minutes, until fragrant.",
                "Add the chickpeas, sweet potatoes, crushed tomatoes, and vegetable broth, and bring to a boil. Reduce the heat to medium-low and simmer for 15-20 minutes, or until the sweet potatoes are tender.",
                "Add the spinach and stir until wilted.",
                "Enjoy!"
        };
        Recipe chickpeaStew = new Recipe("Chickpea Sweet Potato Stew", "Hard", 4,
                chickpeaStewIngredients, chickpeaStewSteps, false,
                R.drawable.chickpea_stew, 65, new String[] {"Vegan"});

        // https://tasty.co/recipe/homemade-dutch-oven-bread
        InventoryItem[] dutchOvenBreadIngredients = {
                new InventoryItem("Water", 2, "cup"),
                new InventoryItem("Active Dry Yeast", 1),
                new InventoryItem("Flour", 4),
                new InventoryItem("Salt", Recipe.NEGLIGIBLE_QUANTITY),
                new InventoryItem("Olive Oil", Recipe.NEGLIGIBLE_QUANTITY),
        };
        String[] dutchOvenBreadSteps = {
                "Stir the yeast into the water and allow the yeast to bloom until foamy.",
                "In a large bowl, mix together the flour and salt by hand. Once incorporated, create a small well in the middle and pour in the water and yeast mixture.",
                "Mix by hand, wetting your working hand before mixing so the dough doesn’t stick to your fingers. The water and flour should come together and a form rough dough that pulls away from the sides of the bowl. If the dough is too sticky, add more flour in small increments, about 1 tablespoon at a time. If the dough is too dry, add more water, 1 tablespoon at a time.",
                "Once the dough comes together, cover and let rise until doubled in size (about 1 ½-2 hours).",
                "Uncover the dough and give it a few pokes with your finger. If the dough has risen properly, it should indent under the pressure of your finger and slowly deflate.",
                "Using your hand or a rubber spatula, start from the rim of the bowl to work the dough loose from the sides and fold it up and towards the center of the bowl. Turn the bowl 90 degrees, and repeat until all the dough has been pulled from the sides and folded towards the center.",
                "Once finished, cover and let the dough rise again for another 1 ½-2 hours.",
                "Once the dough has doubled in size again, gently transfer it from the bowl to a lightly floured surface.",
                "Sprinkle a bit of flour on top of the dough. Using your hands, begin to shape it into a loaf. Fold the dough under itself several times to form a ball, then pinch together the seams of dough underneath.",
                "Place the dough seam-side down in a clean bowl that has been lightly coated with olive oil and dusted with flour.",
                "Cover and let rise for 1 hour.",
                "Meanwhile, place a 6-quart Dutch oven (or heavy cooking pot with oven-safe lid) inside the oven. Preheat the oven to 450˚F (230˚C) with the pot inside for 45 minutes-1 hour.",
                "Carefully remove the pot from the oven and place it on a trivet or heat-safe surface. (Be careful! It’ll be VERY HOT.)",
                "Turn the proofed dough over onto a lightly floured surface and carefully place it inside the pot.",
                "Cover with the lid and return the pot to the oven.",
                "Bake for 45 minutes, removing the lid for the last 15 minutes.",
                "Remove bread from pot, cover, and let cool for 10 minutes before slicing.",
                "Enjoy!"
        };
        Recipe dutchOvenBread = new Recipe("Dutch Oven Bread", "Hard", 8,
                dutchOvenBreadIngredients, dutchOvenBreadSteps, false,
                R.drawable.dutch_oven_bread, 300, new String[] {"Vegan"});

        recipes.getValue().add(chickenPiccata);
        recipes.getValue().add(parmesanChickenTenders);
        recipes.getValue().add(veganPancakes);
        recipes.getValue().add(chickpeaStew);
        recipes.getValue().add(dutchOvenBread);

    }

    // ONLY CALL ONCE
    // inits table
    public void initTableLayout() {
        TableLayout tableLayout = new TableLayout(activity);
        tableLayout.setStretchAllColumns(true);
        mTableLayout.setValue(tableLayout);
        createTable(recipes.getValue());
    }

    private void createTable(List<Recipe> recipes) {
        mTableLayout.getValue().removeAllViews();
        currRecipes.setValue(recipes);
        filterCurrentItems();
        sortCurrentItems();
        createHeaderRow();
        createTableRows(currRecipes.getValue());
    }

    private void sortCurrentItems() {
        switch(sortOrder.getValue()) {
            case NAME_ASC:
                currRecipes.getValue().sort(new Comparator<Recipe>() {
                    @Override
                    public int compare(Recipe r1, Recipe r2) {
                        return r1.getName().toLowerCase()
                                .compareTo(r2.getName().toLowerCase());
                    }
                });
                break;
            case NAME_DSC:
                currRecipes.getValue().sort(new Comparator<Recipe>() {
                    @Override
                    public int compare(Recipe r1, Recipe r2) {
                        return r2.getName().toLowerCase()
                                .compareTo(r1.getName().toLowerCase());
                    }
                });
                break;
            default:
                currRecipes.getValue().sort(new Comparator<Recipe>() {
                    @Override
                    public int compare(Recipe r1, Recipe r2) {
                        return r1.getName().toLowerCase()
                                .compareTo(r2.getName().toLowerCase());
                    }
                });
        }
    }

    private void createTableRows(List<Recipe> recipes) {
        // recipes in alphabetical order where favorites listed first

        // add favorite recipes first
        for (Recipe recipe : recipes) {
            if (recipe.getFavorite())
                addTableRow(recipe);
        }
        for (Recipe recipe : recipes) {
            if (!recipe.getFavorite())
                addTableRow(recipe);
        }
    }

    private void addTableRow(Recipe recipe) {
        /* Create a new row to be added. */
        TableRow tr = new TableRow(activity);

        tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        tr.setBackground(activity.getResources().getDrawable(R.drawable.list_item_white));
        tr.setPadding(DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING);
        addRowElements(tr, recipe, false);
        mTableLayout.getValue().addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

        tr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // pass info to dialog
                Bundle bundle = new Bundle();
                bundle.putSerializable("recipe", recipe);
                RecipeDialogFragment recipeDialogFragment = new RecipeDialogFragment();
                recipeDialogFragment.setArguments(bundle);
                recipeDialogFragment.show(activity.getSupportFragmentManager(), RecipeDialogFragment.TAG);
            }

        });
    }

    // Create a header row for table
    private void createHeaderRow() {
        /* Create a new row to be added. */
        TableRow tr = new TableRow(activity);
        tr.setBackground(activity.getResources().getDrawable(R.drawable.list_item_white));
        tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        tr.setId(tr.generateViewId());
        tr.setPadding(DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING);

        /* Create a TextView to be the row-content. */
        TextView tvFavorite = new TextView(activity);
        setTextViewSettings(tvFavorite, "", FAVORITE_SIZE, true);
        tr.addView(tvFavorite);

        /* Create a TextView to be the row-content. */
        TextView tvName = new TextView(activity);
        tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sortOrder.getValue() == SortOrder.NAME_ASC)
                    sortOrder.setValue(SortOrder.NAME_DSC);
                else if (sortOrder.getValue() == SortOrder.NAME_DSC)
                    sortOrder.setValue(SortOrder.NAME_ASC);
                else
                    sortOrder.setValue(SortOrder.NAME_ASC);
                createTable(currRecipes.getValue());
            }
        });
        String nameText = "Name";
        if (sortOrder.getValue() == SortOrder.NAME_ASC)
            nameText += " " + activity.getResources().getString(R.string.up_arrow);
        else if (sortOrder.getValue() == SortOrder.NAME_DSC)
            nameText += " " + activity.getResources().getString(R.string.down_arrow);
        setTextViewSettings(tvName, nameText, NAME_SIZE, true);
        tr.addView(tvName);

        /* Create a TextView to be the row-content. */
        TextView tvDiet = new TextView(activity);
        setTextViewSettings(tvDiet, "Diet", DIET_SIZE, true);
        tr.addView(tvDiet);

        /* Create a TextView to be the row-content. */
        TextView tvImage = new TextView(activity);
        setTextViewSettings(tvImage, "", IMAGE_SIZE, true);
        tr.addView(tvImage);

        mTableLayout.getValue().addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));
    }

    // Create a imageview with proper settings
    private void setImageSettings(ImageView iv, int maxWidth, int maxHeight, int image) {
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(maxWidth, maxHeight);
        layoutParams.gravity = Gravity.CENTER_VERTICAL;
        iv.setLayoutParams(layoutParams);
        iv.setImageResource(image);
        iv.setPadding(4, 0, 4, 0);
    }

    // Create a imageview with proper settings
    private void setImageButtonSettings(ImageButton ib, int maxWidth, int maxHeight, int image) {
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(maxWidth, maxHeight);
        layoutParams.gravity = Gravity.CENTER_VERTICAL;
        ib.setLayoutParams(layoutParams);
        ib.setImageResource(image);
        ib.setBackgroundColor(0);
        ib.setPadding(4, 0, 4, 0);

    }

    // Create a textview with proper settings
    private void setTextViewSettings(TextView textView, String text, int maxWidth, boolean bold) {
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams();
        layoutParams.gravity = Gravity.CENTER_VERTICAL;
        textView.setLayoutParams(layoutParams);
        textView.setMaxWidth(maxWidth);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setMaxLines(4);
        textView.setTextSize(activity.getResources().getInteger(R.integer.table_entry));
        textView.setText(text);
        if (bold) textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(DEFAULT_PADDING, 0, DEFAULT_PADDING, 0);

    }

    private void addRowElements(TableRow tr, Recipe recipe, boolean bold) {

        /* Create a ImageButton to be the row-content. */
        ImageButton ibFavorite = new ImageButton(activity);
        tr.addView(ibFavorite);
        setImageButtonSettings(ibFavorite, FAVORITE_SIZE, FAVORITE_SIZE, recipe.getFavorite() ? R.drawable.star_filled_64 : R.drawable.star_64);
        ibFavorite.setScaleType(ImageButton.ScaleType.FIT_CENTER);
        ibFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recipe.setFavorite(!recipe.getFavorite());
                setImageButtonSettings(ibFavorite, FAVORITE_SIZE, FAVORITE_SIZE, recipe.getFavorite() ? R.drawable.star_filled_64 : R.drawable.star_64);
                // update order
                createTable(currRecipes.getValue());
            }
        });

        /* Create a TextView to be the row-content. */
        TextView tvName = new TextView(activity);
        setTextViewSettings(tvName, recipe.getName(), NAME_SIZE, bold);
        tr.addView(tvName);

        /* Create a TextView to be the row-content. */
//        TextView tvDifficulty = new TextView(activity);
//        setTextViewSettings(tvDifficulty, recipe.getDifficulty(), DIFFICULTY_SIZE, bold);
//        tr.addView(tvDifficulty);

        /* Create a TextView to be the row-content. */
        TextView tvDiet = new TextView(activity);
        String diets = "";
        if (recipe.getDietaryRestrictions() != null) {
            for (String diet : recipe.getDietaryRestrictions())
                diets += diet + " ";
            diets.substring(0, diets.length()-1);
        }

        setTextViewSettings(tvDiet, diets, DIET_SIZE, false);
        tr.addView(tvDiet);

        /* Create a ImageView to be the row-content. */
        ImageView ivImage = new ImageView(activity);
        setImageSettings(ivImage, IMAGE_SIZE, IMAGE_SIZE, recipe.getImagePath());
        tr.addView(ivImage);
    }

    public void setCurrFilters(HashSet<String> filters) {
        currFilters.setValue(filters);
        createTable(recipes.getValue());
    }

    // recreate table with applied filters
    public void filterCurrentItems() {
        // if no filter, use default table
        if (currFilters.getValue() != null) {
            List<Recipe> filteredRecipes = new ArrayList<>();
            for (Recipe recipe : recipes.getValue())  {
                if (recipe.getSearchStrings().containsAll(currFilters.getValue())) {
                    filteredRecipes.add(recipe);
                }
            }
            currRecipes.setValue(filteredRecipes);
        }
    }

    public List<Recipe> getRecipes() {
        return recipes.getValue();
    }

    public LiveData<TableLayout> getTableLayout() { return mTableLayout; }


}