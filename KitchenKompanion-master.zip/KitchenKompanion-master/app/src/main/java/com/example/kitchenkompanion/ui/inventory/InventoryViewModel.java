package com.example.kitchenkompanion.ui.inventory;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.kitchenkompanion.InventoryItem;
import com.example.kitchenkompanion.R;
import com.example.kitchenkompanion.Recipe;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

public class InventoryViewModel extends ViewModel {

    public static MutableLiveData<List<InventoryItem>> inventoryItems;
    public MutableLiveData<TableLayout> mTableLayout;
    private androidx.fragment.app.FragmentActivity activity;
    private View view;
    private MutableLiveData<HashSet<InventoryItem>> nearExpiredItems;
    private MutableLiveData<HashSet<InventoryItem>> expiredItems;
    private MutableLiveData<Boolean> expiredItemsAlertOn;
    private MutableLiveData<Boolean> nearExpiredItemsAlertOn;
    private MutableLiveData<List<InventoryItem>> currItems;
    private MutableLiveData<HashSet<String>> currFilters;

    private static final int NAME_SIZE = 192;
    private static final int LOCATION_SIZE = 128;
    private static final int QUANTITY_SIZE = 128;
    private static final int DEFAULT_PADDING = 8;

    private enum SortOrder {NAME_ASC, NAME_DSC, LOCATION_ASC, LOCATION_DSC, QUANTITY_ASC, QUANTITY_DSC }
    private MutableLiveData<SortOrder> sortOrder;


    // TODO
    // Important: this is a sketchy get-around to provide activity to view model
    // so that we can create dynamic xml elements.
    // ONLY ASSIGN ONCE
    public void setActivity(androidx.fragment.app.FragmentActivity activity) {
        this.activity = activity;
    }

    // TODO
    // Important: this is a sketchy get-around to provide activity to view model
    // so that we can create dynamic xml elements.
    // ONLY ASSIGN ONCE
    public void setView(View view) {
        this.view = view;
    }

    public InventoryViewModel() {
        mTableLayout = new MutableLiveData<>();
        sortOrder = new MutableLiveData<>();
        sortOrder.setValue(SortOrder.NAME_ASC);
        currFilters = new MutableLiveData<>();
        loadDefaultInventoryItems();
    }

    // init table layout
    // Initializes the header row + default rows
    public void initTableLayout() {
        TableLayout tableLayout = new TableLayout(activity);
        tableLayout.setStretchAllColumns(true);
        mTableLayout.setValue(tableLayout);
        createTable(inventoryItems.getValue());
    }

    private void createTable(List<InventoryItem> items) {
        // update alert
        updateExpiredItemsAlert();
        updateNearExpiredItemsAlert();

        mTableLayout.getValue().removeAllViews();
        currItems.setValue(items);
        filterCurrentItems();
        sortCurrentItems();

        createHeaderRow();
        for (InventoryItem item : currItems.getValue())
            addTableRow(item);
    }

    private void sortCurrentItems() {
        switch(sortOrder.getValue()) {
            case NAME_DSC:
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        return i2.getName().toLowerCase().
                                compareTo(i1.getName().toLowerCase());
                    }
                });
                break;
            case NAME_ASC:
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        return i1.getName().toLowerCase().
                                compareTo(i2.getName().toLowerCase());
                    }
                });
                break;
            case LOCATION_DSC:
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        return i2.getLocation().toLowerCase().
                                compareTo(i1.getLocation().toLowerCase());
                    }
                });
                break;
            case LOCATION_ASC:
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        return i1.getLocation().toLowerCase().
                                compareTo(i2.getLocation().toLowerCase());
                    }
                });
                break;
            case QUANTITY_DSC:
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        double qty1 = i2.getQuantity();
                        double qty2 = i1.getQuantity();
                        if (qty1 > qty2) {
                            return 1;
                        } else if (qty1 < qty2) {
                            return -1;
                        } else {
                            return 0;
                        }
                    }
                });
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        String unit1 = i1.getUnit();
                        String unit2 = i2.getUnit();
                        return unit1.compareTo(unit2);
                    }
                });
                break;
            case QUANTITY_ASC:
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        double qty1 = i1.getQuantity();
                        double qty2 = i2.getQuantity();
                        if (qty1 > qty2) {
                            return 1;
                        } else if (qty1 < qty2) {
                            return -1;
                        } else {
                            return 0;
                        }
                    }
                });
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        String unit1 = i1.getUnit();
                        String unit2 = i2.getUnit();
                        return unit1.compareTo(unit2);
                    }
                });
                break;
            default:
                // sort by name asc
                currItems.getValue().sort(new Comparator<InventoryItem>() {
                    @Override
                    public int compare(InventoryItem i1, InventoryItem i2) {
                        return i1.getName().toLowerCase().
                                compareTo(i2.getName().toLowerCase());
                    }
                });

        }
    }

    // Create a header row for table
    private void createHeaderRow() {
        /* Create a new row to be added. */
        TableRow tr = new TableRow(activity);
        tr.setBackground(activity.getResources().getDrawable(R.drawable.list_item_white));
        tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        tr.setId(tr.generateViewId());
        tr.setPadding(DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING);

        /* Create a TextView to be the row-content. */
        TextView tvName = new TextView(activity);
        tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sortOrder.getValue() == SortOrder.NAME_ASC)
                    sortOrder.setValue(SortOrder.NAME_DSC);
                else if (sortOrder.getValue() == SortOrder.NAME_DSC)
                    sortOrder.setValue(SortOrder.NAME_ASC);
                else
                    sortOrder.setValue(SortOrder.NAME_ASC);
                createTable(currItems.getValue());
            }
        });

        String nameText = "Name";
        if (sortOrder.getValue() == SortOrder.NAME_ASC)
            nameText += " " + activity.getResources().getString(R.string.up_arrow);
        else if (sortOrder.getValue() == SortOrder.NAME_DSC)
            nameText += " " + activity.getResources().getString(R.string.down_arrow);
        setTextViewSettings(tvName, nameText, NAME_SIZE, true);
        tr.addView(tvName);

        /* Create a clickable TextView to be the table header. */
        TextView tvLoc = new TextView(activity);
        tvLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sortOrder.getValue() == SortOrder.LOCATION_ASC)
                    sortOrder.setValue(SortOrder.LOCATION_DSC);
                else if (sortOrder.getValue() == SortOrder.LOCATION_DSC)
                    sortOrder.setValue(SortOrder.LOCATION_ASC);
                else
                    sortOrder.setValue(SortOrder.LOCATION_ASC);
                createTable(currItems.getValue());
            }
        });

        String locationText = "Location";
        if (sortOrder.getValue() == SortOrder.LOCATION_ASC)
            locationText += " " + activity.getResources().getString(R.string.up_arrow);
        else if (sortOrder.getValue() == SortOrder.LOCATION_DSC)
            locationText += " " + activity.getResources().getString(R.string.down_arrow);
        setTextViewSettings(tvLoc, locationText, LOCATION_SIZE, true);
        tr.addView(tvLoc);

        /* Create a TextView to be the row-content. */
        TextView tvQuantity = new TextView(activity);
        tvQuantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sortOrder.getValue() == SortOrder.QUANTITY_ASC)
                    sortOrder.setValue(SortOrder.QUANTITY_DSC);
                else if (sortOrder.getValue() == SortOrder.QUANTITY_DSC)
                    sortOrder.setValue(SortOrder.QUANTITY_ASC);
                else
                    sortOrder.setValue(SortOrder.QUANTITY_ASC);
                createTable(currItems.getValue());
            }
        });
        String quantityText = "Quantity";
        if (sortOrder.getValue() == SortOrder.QUANTITY_ASC)
            quantityText += " " + activity.getResources().getString(R.string.up_arrow);
        else if (sortOrder.getValue() == SortOrder.QUANTITY_DSC)
            quantityText += " " + activity.getResources().getString(R.string.down_arrow);
        setTextViewSettings(tvQuantity, quantityText, QUANTITY_SIZE, true);
        tr.addView(tvQuantity);

        mTableLayout.getValue().addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));
    }

    // Create a row for an inventory item
    private void addTableRow(InventoryItem item) {
        /* Create a new row to be added. */
        TableRow tr = new TableRow(activity);

        tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        tr.setPadding(DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING,DEFAULT_PADDING);
        String quantity = "";
        if ((int) item.getQuantity() == item.getQuantity())
            // can be represented as int, so do that
            quantity += String.valueOf((int) item.getQuantity());
        else
            quantity += String.valueOf(item.getQuantity());
        if (!item.getUnit().equals("#"))
            quantity += " " + item.getUnit();

        String name = item.getName();
        if (!item.getOwner().equals(InventoryItem.DEFAULT_OWNER))
            name += " (" + item.getOwner() + ")";
        addRowElements(tr, name, item.getLocation(), quantity, false);
        mTableLayout.getValue().addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

        tr.setOnClickListener(new View.OnClickListener() {
            @Override
            // when row is clicked, bring up edit screen
            public void onClick(View view) {
                // pass info to dialog
                Bundle bundle = new Bundle();
                bundle.putSerializable("item", item);
                bundle.putInt("row_index", mTableLayout.getValue().indexOfChild(tr)); // index of row
                EditItemDialogFragment editItemDialogFragment = new EditItemDialogFragment();
                editItemDialogFragment.setArguments(bundle);
                editItemDialogFragment.show(activity.getSupportFragmentManager(), EditItemDialogFragment.TAG);
            }
        });

        // set expired background color (if applicable)
        if (item.expired())
            tr.setBackground(activity.getResources().getDrawable(R.drawable.list_item_red));
        else if (item.nearExpiration())
            tr.setBackground(activity.getResources().getDrawable(R.drawable.list_item_yellow));
        else
            tr.setBackground(activity.getResources().getDrawable(R.drawable.list_item_white));
    }

    // Create a textview with proper settings
    private void setTextViewSettings(TextView textView, String text, int maxWidth, boolean bold) {
        textView.setMaxWidth(maxWidth);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setMaxLines(1);
        textView.setTextSize(activity.getResources().getInteger(R.integer.table_entry));
        textView.setText(text);
        textView.setPadding(DEFAULT_PADDING, 0, DEFAULT_PADDING, 0);
        if (bold) textView.setTypeface(null, Typeface.BOLD);
    }

    // Create 4 textviews for each row
    private void addRowElements(TableRow tr, String name, String loc, String quantity, boolean bold) {

        /* Create a TextView to be the row-content. */
        TextView tvName = new TextView(activity);
        setTextViewSettings(tvName, name, NAME_SIZE, bold);
        tr.addView(tvName);

        /* Create a TextView to be the row-content. */
        TextView tvLoc = new TextView(activity);
        setTextViewSettings(tvLoc, loc, LOCATION_SIZE, bold);
        tr.addView(tvLoc);

        /* Create a TextView to be the row-content. */
        TextView tvQuantity = new TextView(activity);
        setTextViewSettings(tvQuantity, quantity, QUANTITY_SIZE, bold);
        tr.addView(tvQuantity);

    }

    public List<InventoryItem> getInventoryItems() {
        if (inventoryItems == null && inventoryItems.getValue() == null) {
            loadDefaultInventoryItems();
        }
        return inventoryItems.getValue();
    }

    // init default data
    private void loadDefaultInventoryItems() {
        inventoryItems = new MutableLiveData<List<InventoryItem>>();
        expiredItems = new MutableLiveData<>();
        nearExpiredItems = new MutableLiveData<>();
        expiredItemsAlertOn = new MutableLiveData<>();
        nearExpiredItemsAlertOn = new MutableLiveData<>();
        expiredItems.setValue(new HashSet<>());
        nearExpiredItems.setValue(new HashSet<>());
        expiredItemsAlertOn.setValue(new Boolean(true));
        nearExpiredItemsAlertOn.setValue(new Boolean(true));
        currItems = new MutableLiveData<List<InventoryItem>>();

        InventoryItem[] defaultInventoryItems = {
                new InventoryItem("Chicken Broth", InventoryItem.DEFAULT_OWNER, 2, "Pantry", LocalDate.now().plusDays(14), "cup"),
                new InventoryItem("Lemon", InventoryItem.DEFAULT_OWNER, 4, "Fridge", LocalDate.now().plusDays(14), "#"),
                new InventoryItem("Flour", InventoryItem.DEFAULT_OWNER, 32, "Pantry", LocalDate.now().plusDays(14), "cup"),
                new InventoryItem("Salt", InventoryItem.DEFAULT_OWNER, 1, "Pantry", LocalDate.now().plusDays(14), "#"),
                new InventoryItem("Pepper", InventoryItem.DEFAULT_OWNER, 1, "Pantry", LocalDate.now().plusDays(14), "#"),
                // other owner
                new InventoryItem("Butter", "Bill", 3, "Fridge", LocalDate.now().plusDays(14), "tbsp"),
                // expires in 3 days (yellow popup)
                new InventoryItem("Chicken Breast", InventoryItem.DEFAULT_OWNER, 2, "Fridge", LocalDate.now().plusDays(3), "#"),
                // expired (red popup)
                new InventoryItem("Butter", InventoryItem.DEFAULT_OWNER, 2, "Fridge", LocalDate.now().minusDays(1), "tbsp"),
        };

        inventoryItems.setValue(new ArrayList<>(Arrays.asList(defaultInventoryItems)));
    }

    // add item to inventory (and update rows)
    public void addInventoryItem(InventoryItem item) {
        if (inventoryItems == null) {
            loadDefaultInventoryItems();
        }
        inventoryItems.getValue().add(item);
        addTableRow(item);
    }

    // delete item in inventory (and update rows)
    public void removeInventoryItem(InventoryItem item) {
        if (inventoryItems != null) {
            inventoryItems.getValue().remove(item);
            createTable(inventoryItems.getValue());
        }
    }

    // refresh the screen (after edit or addition to inventory items list)
    public void refreshTable() {
        createTable(inventoryItems.getValue());
    }

    // TODO this is reliant on index and may break if we do sorting
    // edit item in inventory (and update rows)
    public void editInventoryItem(InventoryItem newItem, int index) {
        if (inventoryItems != null) {
            createTable(currItems.getValue());
        }
    }

    // for deducting items from recipe list
    public void removeMultipleInventoryItems(InventoryItem[] items) {
        ArrayList<InventoryItem> inventoryItemsToDelete = new ArrayList<>();

        for (InventoryItem item : items) {
            double quantityToDeduct = item.getQuantity();
            if (quantityToDeduct > Recipe.NEGLIGIBLE_QUANTITY)
            {
                for (InventoryItem inventoryItem : inventoryItems.getValue()) {
                    // compare with name and owner
                    if (inventoryItem.getName().equalsIgnoreCase(item.getName())
                            && inventoryItem.getOwner().equals(InventoryItem.DEFAULT_OWNER)) {
                        // inventory item will not remain after recipe
                        if (inventoryItem.getQuantity() <= quantityToDeduct) {
                            quantityToDeduct -= inventoryItem.getQuantity();
                            inventoryItemsToDelete.add(inventoryItem);
                        }
                        // inventory item is enough for recipe
                        else {
                            inventoryItem.setQuantity(inventoryItem.getQuantity() - quantityToDeduct);
                            quantityToDeduct = 0;
                            break;
                        }
                    }
                }
            }
        }

        // delete items marked for deletion
        for (InventoryItem item :inventoryItemsToDelete) {
            inventoryItems.getValue().remove(item);
        }

        // recreate table with updated inventory items
        createTable(inventoryItems.getValue());
    }

    public double getMyItemQuantity(String name) {
        double ret = 0;

        if (inventoryItems != null) {
            for (InventoryItem item : inventoryItems.getValue()) {
                if (item.getName().equalsIgnoreCase(name) &&
                        item.getOwner().equals(InventoryItem.DEFAULT_OWNER)) {
                    ret += item.getQuantity();
                }
            }
        }

        return ret;
    }

    public void printInventoryItems() {
        if (inventoryItems != null)
            System.out.println("Printing items");
            for (InventoryItem item : inventoryItems.getValue()) {
                System.out.println(item.toString());
            }
    }

    public void setCurrFilters(HashSet<String> filters) {
        currFilters.setValue(filters);
        createTable(inventoryItems.getValue());
    }

    // recreate table with applied filters
    public void filterCurrentItems() {
        // if no filter, use default table
        if (currFilters.getValue() != null) {
            List<InventoryItem> filteredItems = new ArrayList<>();
            for (InventoryItem item : currItems.getValue())  {
                if (item.getSearchStrings().containsAll(currFilters.getValue())) {
                    filteredItems.add(item);
                }
            }
            currItems.setValue(filteredItems);
        }
    }

    // update the alert
    private void updateExpiredItemsAlert() {
        boolean updated = updateExpiredItems();
        int numExpired = expiredItems.getValue().size();

        if (numExpired > 0 && (expiredItemsAlertOn.getValue().booleanValue() || updated)) {
            ((LinearLayout) view.findViewById(R.id.inventory_expired_alert_layout)).setVisibility(View.VISIBLE);
            String alertText;
            if (numExpired == 1)
                alertText = "1 item has expired!";
            else
                alertText = numExpired + " items have expired!";
            ((TextView) view.findViewById(R.id.inventory_expired_alert_text)).setText(alertText);
        } else
            ((LinearLayout) view.findViewById(R.id.inventory_expired_alert_layout)).setVisibility(View.GONE);
    }

    // update the alert
    private void updateNearExpiredItemsAlert() {
        boolean updated = updateNearExpiredItems();
        int numExpired = nearExpiredItems.getValue().size();
        if (numExpired > 0 && (nearExpiredItemsAlertOn.getValue().booleanValue() || updated)) {
            ((LinearLayout) view.findViewById(R.id.inventory_near_expired_alert_layout)).setVisibility(View.VISIBLE);
            String alertText;
            if (numExpired == 1)
                alertText = "1 item will expire within 3 days!";
            else
                alertText = numExpired + " item will expire within 3 days!";
            ((TextView) view.findViewById(R.id.inventory_near_expired_alert_text)).setText(alertText);
        } else
            ((LinearLayout) view.findViewById(R.id.inventory_near_expired_alert_layout)).setVisibility(View.GONE);
    }

    // update set with new items that have expired and remove items that have been deleted
    // returns true if new items have been expired
    private boolean updateExpiredItems() {
        boolean ret = false;
        HashSet<InventoryItem> toDelete = new HashSet<>();
        HashSet<InventoryItem> toAdd = new HashSet<>();

        // compute items to remove
        for (InventoryItem item : expiredItems.getValue()) {
            if (!inventoryItems.getValue().contains(item))
                toDelete.add(item);
        }

        // compute items to add
        for (InventoryItem item : inventoryItems.getValue()) {
            if (item.expired() && !expiredItems.getValue().contains(item)) {
                toAdd.add(item);
                ret = true;
                expiredItemsAlertOn.setValue(new Boolean(true));
            }
        }

        expiredItems.getValue().removeAll(toDelete);
        expiredItems.getValue().addAll(toAdd);

        return ret;
    }

    // update set with new items that have expired and remove items that have been deleted
    // returns true if new items have been expired
    private boolean updateNearExpiredItems() {
        boolean ret = false;
        HashSet<InventoryItem> toDelete = new HashSet<>();
        HashSet<InventoryItem> toAdd = new HashSet<>();

        // compute items to remove
        for (InventoryItem item : nearExpiredItems.getValue()) {
            if (!inventoryItems.getValue().contains(item))
                toDelete.add(item);
        }

        // compute items to add
        for (InventoryItem item : inventoryItems.getValue()) {
            if (item.nearExpiration() && !nearExpiredItems.getValue().contains(item)) {
                toAdd.add(item);
                ret = true;
                nearExpiredItemsAlertOn.setValue(new Boolean(true));
            }
        }

        nearExpiredItems.getValue().removeAll(toDelete);
        nearExpiredItems.getValue().addAll(toAdd);

        return ret;
    }

    public void setExpiredAlertOff() {
        expiredItemsAlertOn.setValue(new Boolean(false));
    }

    public void setNearExpiredAlertOff() {
        nearExpiredItemsAlertOn.setValue(new Boolean(false));
    }

    public LiveData<TableLayout> getTableLayout() { return mTableLayout; }

    public static InventoryItem matchInInventoryItems(InventoryItem i) {
        for (InventoryItem item : inventoryItems.getValue()) {
            if (item.compareDefiningFields(i)) {
                return item;
            }
        }
        return null;
    }
}